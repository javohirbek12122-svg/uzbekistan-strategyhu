import { flag } from 'flags/next';
import { vercelAdapter } from '@flags-sdk/vercel';

/** Vercel-managed feature flag. */
export const uzbekiston = flag({
  key: 'uzbekiston',
  adapter: vercelAdapter(),
});
